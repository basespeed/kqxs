# first_child

```php
first_child ( ) : mixed
```

Returns the first child node of the current node or null if the current nod has no child nodes.